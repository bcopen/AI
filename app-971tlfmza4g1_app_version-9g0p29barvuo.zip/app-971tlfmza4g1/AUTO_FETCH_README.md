# 自动抓取活动功能说明

## 功能概述

系统已实现自动抓取全网AI和Web3活动的功能，包括：

1. **智能抓取**：从多个数据源抓取活动信息
2. **自动分类**：根据关键词自动识别活动类型并打标签
3. **去重处理**：自动检测并跳过重复的活动
4. **定时更新**：支持配置定时任务，每天自动抓取
5. **手动触发**：管理员可以在管理页面手动触发抓取

## 技术实现

### Edge Function

已创建 `fetch-events` Edge Function，位于：
```
supabase/functions/fetch-events/index.ts
```

功能包括：
- 从多个数据源抓取活动数据
- 自动识别AI和Web3相关关键词
- 智能分类标签（AI技术、区块链、Web3、NFT、元宇宙等）
- 活动类型识别（技术峰会、创业交流、开发工作坊、研讨会、黑客松）
- 基于标题和时间的去重逻辑
- 批量插入数据库

### 管理页面

已创建管理页面，位于：
```
src/pages/auto-fetch/index.tsx
```

功能包括：
- 手动触发抓取按钮
- 实时显示抓取进度
- 抓取日志记录
- 成功/失败统计

## 配置定时任务

### 方案1：使用Supabase Cron Jobs（推荐）

在Supabase Dashboard中配置：

1. 进入项目的 Database → Cron Jobs
2. 创建新的Cron Job：
   ```sql
   -- 每天凌晨2点执行
   SELECT cron.schedule(
     'fetch-events-daily',
     '0 2 * * *',
     $$
     SELECT net.http_post(
       url := 'https://your-project-ref.supabase.co/functions/v1/fetch-events',
       headers := jsonb_build_object(
         'Content-Type', 'application/json',
         'Authorization', 'Bearer YOUR_ANON_KEY'
       ),
       body := '{}'::jsonb
     );
     $$
   );
   ```

3. 替换以下内容：
   - `your-project-ref`：你的Supabase项目引用ID
   - `YOUR_ANON_KEY`：你的Supabase匿名密钥

### 方案2：使用外部Cron服务

可以使用以下服务：

1. **GitHub Actions**（免费）
   - 创建 `.github/workflows/fetch-events.yml`
   - 配置定时触发
   - 调用Edge Function

2. **Vercel Cron Jobs**（免费）
   - 部署一个简单的API路由
   - 配置vercel.json中的cron
   - 调用Edge Function

3. **云服务定时任务**
   - 阿里云函数计算
   - 腾讯云云函数
   - AWS Lambda

## 数据源配置

当前实现使用模拟数据，实际应用中需要配置真实的数据源：

### 推荐数据源

1. **活动平台API**
   - 活动行（Huodongxing）
   - 互动吧（Hdb）
   - Eventbrite
   - Meetup

2. **RSS订阅源**
   - 技术博客的活动RSS
   - 行业媒体的活动频道

3. **社交媒体**
   - 微信公众号文章抓取
   - 微博话题监控

### 配置方法

在 `supabase/functions/fetch-events/index.ts` 中修改 `fetchEventsFromSources` 函数：

```typescript
async function fetchEventsFromSources(): Promise<EventData[]> {
  const events: EventData[] = []

  // 示例：从活动平台API获取
  try {
    const response = await fetch('https://api.example.com/events?category=ai,web3', {
      headers: {
        'Authorization': 'Bearer YOUR_API_KEY'
      }
    })
    const data = await response.json()

    // 处理返回的数据
    for (const item of data.events) {
      events.push({
        title: item.title,
        event_time: formatTime(item.start_time),
        location: item.location,
        description: item.description,
        registration_method: item.registration_url,
        image_url: item.cover_image,
        tags: autoTagEvent(item.title, item.description)
      })
    }
  } catch (error) {
    console.error('抓取失败:', error)
  }

  return events
}
```

## 关键词配置

可以在Edge Function中自定义关键词：

```typescript
// AI相关关键词
const AI_KEYWORDS = [
  'AI', '人工智能', '机器学习', '深度学习', 
  '大模型', 'GPT', 'ChatGPT', '生成式AI', 'AIGC'
]

// Web3相关关键词
const WEB3_KEYWORDS = [
  'Web3', '区块链', 'blockchain', 'NFT', 
  '元宇宙', 'DeFi', '智能合约', '加密货币', '数字货币'
]

// 活动类型关键词
const EVENT_TYPE_KEYWORDS = {
  '技术峰会': ['峰会', 'summit', '大会', 'conference'],
  '创业交流': ['创业', '投资', '路演', 'demo day'],
  '开发工作坊': ['工作坊', 'workshop', '实战', '训练营'],
  '研讨会': ['研讨会', 'seminar', '论坛', 'forum'],
  '黑客松': ['黑客松', 'hackathon', '编程马拉松']
}
```

## 使用说明

### 管理员操作

1. 登录管理员账号
2. 进入"我的"页面
3. 点击"自动抓取活动"按钮
4. 在管理页面点击"立即抓取活动"
5. 查看抓取日志和结果

### 抓取结果

- **成功**：显示抓取总数、新增数量、跳过数量
- **失败**：显示错误信息
- **日志**：记录每次抓取的时间和结果

## 注意事项

1. **API限制**：注意各平台的API调用频率限制
2. **数据质量**：建议定期检查抓取的数据质量
3. **去重逻辑**：基于标题和时间去重，可能需要调整
4. **图片处理**：确保图片URL可访问
5. **时间格式**：统一使用"2026年3月15日 09:00-18:00"格式

## 后续优化建议

1. **多数据源支持**：集成更多活动平台API
2. **智能推荐**：根据用户兴趣推荐活动
3. **数据清洗**：提升数据质量和准确性
4. **图片优化**：自动压缩和CDN加速
5. **通知功能**：新活动推送通知
6. **数据分析**：活动热度和趋势分析

## 故障排查

### 抓取失败

1. 检查Edge Function日志
2. 验证API密钥是否有效
3. 确认网络连接正常
4. 检查数据源是否可访问

### 数据重复

1. 检查去重逻辑
2. 验证标题和时间格式
3. 清理重复数据

### 标签错误

1. 检查关键词配置
2. 调整匹配规则
3. 手动修正标签

## 技术支持

如有问题，请联系技术团队或查看：
- Supabase文档：https://supabase.com/docs
- Edge Functions文档：https://supabase.com/docs/guides/functions
- Cron Jobs文档：https://supabase.com/docs/guides/database/extensions/pg_cron
