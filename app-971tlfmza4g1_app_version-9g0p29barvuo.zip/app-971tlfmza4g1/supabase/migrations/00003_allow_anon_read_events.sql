-- 删除旧的只允许authenticated用户查看活动的策略
DROP POLICY IF EXISTS "所有人可以查看活动" ON events;

-- 创建新的策略，允许所有人（包括未登录用户）查看活动
CREATE POLICY "所有人可以查看活动" ON events
  FOR SELECT USING (true);

-- 添加注释说明
COMMENT ON POLICY "所有人可以查看活动" ON events IS '允许所有用户（包括未登录用户）查看活动列表和详情，支持小程序分享功能';
