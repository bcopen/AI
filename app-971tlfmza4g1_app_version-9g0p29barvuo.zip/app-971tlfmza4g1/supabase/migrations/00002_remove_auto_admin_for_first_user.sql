-- 修改用户同步触发器函数，移除第一个用户自动成为管理员的逻辑
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  extracted_username text;
BEGIN
  -- 从email中提取用户名（去掉@miaoda.com后缀）
  extracted_username := CASE 
    WHEN NEW.email LIKE '%@miaoda.com' THEN 
      SUBSTRING(NEW.email FROM '^(.+)@miaoda\.com$')
    WHEN NEW.email LIKE '%@wechat.login' THEN
      NULL
    ELSE 
      NEW.email
  END;
  
  -- 插入用户资料，所有用户默认为普通用户
  INSERT INTO public.profiles (id, username, email, phone, role, openid)
  VALUES (
    NEW.id,
    extracted_username,
    CASE WHEN NEW.email LIKE '%@miaoda.com' OR NEW.email LIKE '%@wechat.login' THEN NULL ELSE NEW.email END,
    NEW.phone,
    'user'::public.user_role,
    COALESCE((NEW.raw_user_meta_data->>'openid')::text, NULL)
  );
  RETURN NEW;
END;
$$;