import {Button, Image, Text, View} from '@tarojs/components'
import Taro, {getEnv} from '@tarojs/taro'
import type {Event} from '@/db/types'

interface EventCardProps {
  event: Event
  onShare?: (eventId: string) => void
}

export function EventCard({event, onShare}: EventCardProps) {
  const handleClick = () => {
    Taro.navigateTo({
      url: `/pages/detail/index?id=${event.id}`
    })
  }

  const handleShareClick = (e: any) => {
    e.stopPropagation() // 阻止事件冒泡，避免触发卡片点击

    // 检测运行环境
    const env = getEnv()

    if (env === 'WEAPP') {
      // 微信小程序环境，设置分享事件ID
      if (onShare) {
        onShare(event.id)
      }
    } else {
      // H5环境，显示提示
      Taro.showToast({
        title: '分享功能仅在微信小程序中可用',
        icon: 'none',
        duration: 2000
      })
    }
  }

  // 检测运行环境
  const isWeApp = getEnv() === 'WEAPP'

  return (
    <View className="bg-card rounded-xl overflow-hidden shadow-card mb-4">
      <View onClick={handleClick}>
        {/* 活动图片 */}
        {event.image_url && (
          <View className="w-full h-48 bg-muted">
            <Image src={event.image_url} mode="aspectFill" className="w-full h-full" />
          </View>
        )}

        {/* 活动信息 */}
        <View className="p-4">
          <Text className="text-lg font-bold text-foreground block mb-3 line-clamp-2">{event.title}</Text>

          <View className="flex items-center mb-2">
            <View className="i-mdi-clock-outline text-base text-primary mr-2" />
            <Text className="text-sm text-muted-foreground">{event.event_time}</Text>
          </View>

          <View className="flex items-center">
            <View className="i-mdi-map-marker text-base text-primary mr-2" />
            <Text className="text-sm text-muted-foreground line-clamp-1">{event.location}</Text>
          </View>
        </View>
      </View>

      {/* 分享按钮 */}
      {onShare && (
        <View className="px-4 pb-4">
          <Button
            className="w-full bg-accent text-accent-foreground text-sm font-medium rounded-lg py-2 break-keep"
            data-event-id={event.id}
            {...(isWeApp ? {openType: 'share'} : {})}
            onClick={handleShareClick}>
            <View className="flex items-center justify-center">
              <View className="i-mdi-share-variant text-base mr-1" />
              <Text className="text-sm">分享活动</Text>
            </View>
          </Button>
        </View>
      )}
    </View>
  )
}
