-- 为events表添加tags字段
ALTER TABLE events ADD COLUMN IF NOT EXISTS tags TEXT[] DEFAULT '{}';

-- 添加注释
COMMENT ON COLUMN events.tags IS '活动标签数组，用于分类和筛选（如：AI技术、区块链、技术峰会等）';

-- 为现有活动添加标签
UPDATE events SET tags = ARRAY['AI技术', '技术峰会'] WHERE title = '2026 AI技术峰会·北京站';
UPDATE events SET tags = ARRAY['AI技术', '创业交流'] WHERE title = 'AI创业者交流会';
UPDATE events SET tags = ARRAY['AI技术', '生成式AI', '开发工作坊'] WHERE title = '生成式AI应用开发工作坊';
UPDATE events SET tags = ARRAY['区块链', 'Web3', '技术峰会'] WHERE title = 'Web3开发者大会2026';
UPDATE events SET tags = ARRAY['区块链', '研讨会'] WHERE title = '区块链技术与应用研讨会';
UPDATE events SET tags = ARRAY['NFT', '元宇宙', '研讨会'] WHERE title = 'NFT与元宇宙创新论坛';
UPDATE events SET tags = ARRAY['AI技术', 'Web3', '技术峰会'] WHERE title = 'AI×Web3：未来科技融合峰会';
UPDATE events SET tags = ARRAY['AI技术', '区块链', '研讨会'] WHERE title = '去中心化AI模型训练研讨会';
UPDATE events SET tags = ARRAY['AI技术', '黑客松'] WHERE title LIKE '%Hackathon%';
UPDATE events SET tags = ARRAY['AI技术', 'Web3'] WHERE title = 'AI和Web3融合' OR title = 'Web3meetup';
