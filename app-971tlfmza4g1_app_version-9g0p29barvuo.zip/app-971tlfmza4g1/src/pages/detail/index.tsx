import {Button, Image, ScrollView, Text, View} from '@tarojs/components'
import Taro, {useRouter, useShareAppMessage, useShareTimeline} from '@tarojs/taro'
import {useCallback, useEffect, useState} from 'react'
import {checkIsAdmin, deleteEvent, getEventById} from '@/db/api'
import type {Event} from '@/db/types'

function Detail() {
  const router = useRouter()
  const {id} = router.params
  const [event, setEvent] = useState<Event | null>(null)
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [deleting, setDeleting] = useState(false)

  // 配置分享到好友/群聊
  useShareAppMessage(() => {
    if (!event) {
      return {
        title: '海拉的AI&WEB3 - 发现最新的AI与Web3活动',
        path: '/pages/home/index'
      }
    }
    return {
      title: event.title,
      path: `/pages/detail/index?id=${event.id}`,
      imageUrl: event.image_url || undefined
    }
  })

  // 配置分享到朋友圈
  useShareTimeline(() => {
    return {
      title: event?.title || '海拉的AI&WEB3 - 探索人工智能与区块链的未来'
    }
  })

  // 一键复制报名方式
  const handleCopyRegistration = () => {
    if (!event) return

    Taro.setClipboardData({
      data: event.registration_method,
      success: () => {
        Taro.showToast({
          title: '已复制到剪贴板',
          icon: 'success',
          duration: 2000
        })
      },
      fail: () => {
        Taro.showToast({
          title: '复制失败',
          icon: 'none'
        })
      }
    })
  }

  const loadEvent = useCallback(async (eventId: string) => {
    setLoading(true)
    try {
      const data = await getEventById(eventId)
      setEvent(data)
    } finally {
      setLoading(false)
    }
  }, [])

  const checkAdmin = useCallback(async () => {
    const adminStatus = await checkIsAdmin()
    setIsAdmin(adminStatus)
  }, [])

  useEffect(() => {
    if (id) {
      loadEvent(id)
    }
    checkAdmin()
  }, [id, loadEvent, checkAdmin])

  // 处理编辑
  const handleEdit = () => {
    if (!event) return
    Taro.navigateTo({
      url: `/pages/edit/index?id=${event.id}`
    })
  }

  // 处理删除
  const handleDelete = () => {
    if (!event) return

    Taro.showModal({
      title: '确认删除',
      content: '确定要删除这个活动吗？删除后无法恢复。',
      success: async (res) => {
        if (res.confirm) {
          setDeleting(true)
          try {
            const success = await deleteEvent(event.id)
            if (success) {
              Taro.showToast({
                title: '删除成功',
                icon: 'success'
              })
              setTimeout(() => {
                Taro.switchTab({url: '/pages/home/index'})
              }, 1000)
            } else {
              Taro.showToast({
                title: '删除失败',
                icon: 'none'
              })
            }
          } finally {
            setDeleting(false)
          }
        }
      }
    })
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-gradient-subtle flex items-center justify-center">
        <View className="i-mdi-loading text-4xl text-primary animate-spin mb-4" />
        <Text className="text-sm text-muted-foreground">加载中...</Text>
      </View>
    )
  }

  if (!event) {
    return (
      <View className="min-h-screen bg-gradient-subtle flex flex-col items-center justify-center px-6">
        <View className="i-mdi-alert-circle text-6xl text-muted mb-4" />
        <Text className="text-base text-muted-foreground mb-6">活动不存在</Text>
        <Button
          className="bg-primary text-primary-foreground text-sm px-8 py-2 rounded-lg break-keep"
          onClick={() => Taro.navigateBack()}>
          返回
        </Button>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gradient-subtle">
      <ScrollView scrollY className="h-screen">
        {/* 活动图片 */}
        {event.image_url && (
          <View className="w-full h-64 bg-muted relative">
            <Image src={event.image_url} mode="aspectFill" className="w-full h-full" />
            {/* 返回按钮 */}
            <View
              className="absolute top-4 left-4 w-10 h-10 bg-card bg-opacity-90 rounded-full flex items-center justify-center shadow-card"
              onClick={() => Taro.navigateBack()}>
              <View className="i-mdi-arrow-left text-xl text-foreground" />
            </View>
          </View>
        )}

        {/* 如果没有图片，显示顶部返回按钮 */}
        {!event.image_url && (
          <View className="px-6 pt-4 pb-2">
            <View
              className="w-10 h-10 bg-card rounded-full flex items-center justify-center shadow-card"
              onClick={() => Taro.navigateBack()}>
              <View className="i-mdi-arrow-left text-xl text-foreground" />
            </View>
          </View>
        )}

        {/* 活动详情 */}
        <View className="px-6 py-6">
          {/* 标题 */}
          <Text className="text-2xl font-bold text-foreground block mb-6">{event.title}</Text>

          {/* 时间 */}
          <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
            <View className="flex items-start">
              <View className="i-mdi-clock-outline text-xl text-primary mr-3 mt-1" />
              <View className="flex-1">
                <Text className="text-sm text-muted-foreground block mb-1">活动时间</Text>
                <Text className="text-base text-foreground block">{event.event_time}</Text>
              </View>
            </View>
          </View>

          {/* 地点 */}
          <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
            <View className="flex items-start">
              <View className="i-mdi-map-marker text-xl text-primary mr-3 mt-1" />
              <View className="flex-1">
                <Text className="text-sm text-muted-foreground block mb-1">活动地点</Text>
                <Text className="text-base text-foreground block">{event.location}</Text>
              </View>
            </View>
          </View>

          {/* 活动介绍 */}
          <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
            <View className="flex items-start">
              <View className="i-mdi-text-box-outline text-xl text-primary mr-3 mt-1" />
              <View className="flex-1">
                <Text className="text-sm text-muted-foreground block mb-2">活动介绍</Text>
                <Text className="text-base text-foreground block leading-relaxed">{event.description}</Text>
              </View>
            </View>
          </View>

          {/* 报名方式 */}
          <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
            <View className="flex items-start">
              <View className="i-mdi-account-plus-outline text-xl text-primary mr-3 mt-1" />
              <View className="flex-1">
                <Text className="text-sm text-muted-foreground block mb-2">报名方式</Text>
                <Text className="text-base text-foreground block leading-relaxed mb-3">
                  {event.registration_method}
                </Text>
                <Button
                  className="bg-accent text-accent-foreground text-sm font-medium rounded-lg py-2 break-keep"
                  onClick={handleCopyRegistration}>
                  <View className="flex items-center justify-center">
                    <View className="i-mdi-content-copy text-base mr-1" />
                    <Text className="text-sm">一键复制</Text>
                  </View>
                </Button>
              </View>
            </View>
          </View>

          {/* 底部操作按钮 */}
          {isAdmin ? (
            <View className="flex gap-3 mb-6">
              <Button
                className="flex-1 bg-secondary text-secondary-foreground text-base font-medium rounded-lg py-3 break-keep"
                onClick={handleEdit}>
                编辑活动
              </Button>
              <Button
                className="flex-1 bg-destructive text-destructive-foreground text-base font-medium rounded-lg py-3 break-keep"
                loading={deleting}
                onClick={handleDelete}>
                删除活动
              </Button>
            </View>
          ) : null}

          {/* 返回按钮 */}
          <Button
            className="w-full bg-secondary text-secondary-foreground text-base font-medium rounded-lg py-3 break-keep mb-6"
            onClick={() => Taro.navigateBack()}>
            <View className="flex items-center justify-center">
              <View className="i-mdi-arrow-left text-lg mr-1" />
              <Text className="text-base">返回</Text>
            </View>
          </Button>
        </View>
      </ScrollView>
    </View>
  )
}

export default Detail
