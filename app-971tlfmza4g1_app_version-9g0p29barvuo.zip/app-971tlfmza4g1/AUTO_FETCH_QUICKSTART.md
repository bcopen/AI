# 自动抓取活动 - 快速开始指南

## 功能简介

系统已实现自动抓取全网AI和Web3活动的功能，可以：
- 🤖 自动从多个数据源抓取活动信息
- 🏷️ 智能识别活动类型并自动打标签
- 🔄 自动去重，避免重复添加
- ⏰ 支持定时任务，每天自动更新
- 📊 实时查看抓取日志和统计

## 快速使用

### 1. 手动触发抓取

1. 使用管理员账号登录（用户名：admin）
2. 进入"我的"页面
3. 点击"自动抓取活动"按钮
4. 在管理页面点击"立即抓取活动"
5. 等待抓取完成，查看结果

### 2. 查看抓取结果

抓取完成后，页面会显示：
- ✅ 抓取总数
- ➕ 新增活动数量
- ⏭️ 跳过的重复活动数量
- 📝 详细的抓取日志

### 3. 配置定时任务（可选）

如需每天自动抓取，请按照以下步骤配置：

#### 方法1：Supabase Cron Jobs（推荐）

1. 登录Supabase Dashboard
2. 进入项目的 Database → Extensions
3. 启用 `pg_cron` 扩展
4. 进入 SQL Editor，执行以下SQL：

```sql
-- 每天凌晨2点自动抓取
SELECT cron.schedule(
  'fetch-events-daily',
  '0 2 * * *',
  $$
  SELECT net.http_post(
    url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-events',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer YOUR_ANON_KEY'
    ),
    body := '{}'::jsonb
  );
  $$
);
```

5. 替换以下内容：
   - `YOUR_PROJECT_REF`：你的Supabase项目ID（在项目设置中查看）
   - `YOUR_ANON_KEY`：你的Supabase匿名密钥（在项目设置 → API中查看）

#### 方法2：外部定时服务

也可以使用以下服务：
- GitHub Actions（免费）
- Vercel Cron Jobs（免费）
- 云函数定时触发（阿里云、腾讯云、AWS等）

详细配置方法请参考 `AUTO_FETCH_README.md`

## 工作原理

### 智能分类

系统会根据以下关键词自动识别活动类型：

**AI相关**：
- AI、人工智能、机器学习、深度学习
- 大模型、GPT、ChatGPT、生成式AI、AIGC

**Web3相关**：
- Web3、区块链、blockchain、NFT
- 元宇宙、DeFi、智能合约、加密货币

**活动类型**：
- 技术峰会：峰会、summit、大会、conference
- 创业交流：创业、投资、路演、demo day
- 开发工作坊：工作坊、workshop、实战、训练营
- 研讨会：研讨会、seminar、论坛、forum
- 黑客松：黑客松、hackathon、编程马拉松

### 去重机制

系统会检查活动的标题和时间：
- 如果标题和时间完全相同，则跳过
- 避免重复添加相同的活动

## 数据源配置

当前版本使用模拟数据作为示例。如需接入真实数据源，请：

1. 联系技术团队获取API密钥
2. 修改 `supabase/functions/fetch-events/index.ts`
3. 配置真实的API端点和认证信息

推荐的数据源：
- 活动行（Huodongxing）
- 互动吧（Hdb）
- Eventbrite
- Meetup
- 各类技术社区的RSS订阅

## 常见问题

### Q: 抓取失败怎么办？

A: 请检查：
1. 网络连接是否正常
2. Edge Function是否部署成功
3. 查看抓取日志中的错误信息
4. 联系技术支持

### Q: 如何修改抓取频率？

A: 修改Cron表达式：
- `0 2 * * *`：每天凌晨2点
- `0 */6 * * *`：每6小时一次
- `0 0 * * 1`：每周一凌晨

### Q: 如何添加新的数据源？

A: 请参考 `AUTO_FETCH_README.md` 中的详细说明，或联系技术团队。

### Q: 抓取的活动质量如何保证？

A: 系统会：
1. 自动过滤非AI/Web3相关活动
2. 去除重复活动
3. 管理员可以手动审核和删除不合适的活动

## 技术支持

如有问题，请：
1. 查看 `AUTO_FETCH_README.md` 详细文档
2. 查看Supabase Dashboard中的Edge Function日志
3. 联系技术团队

## 更新日志

### v1.0.0 (2026-01-27)
- ✅ 实现基础抓取功能
- ✅ 智能分类和标签
- ✅ 去重逻辑
- ✅ 管理页面
- ✅ 手动触发
- ✅ 日志记录

### 计划中的功能
- 🔜 更多数据源支持
- 🔜 数据质量评分
- 🔜 活动推荐算法
- 🔜 自动图片优化
- 🔜 活动提醒通知
