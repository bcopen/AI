// Edge Function: 自动抓取AI和Web3活动
import {createClient} from 'jsr:@supabase/supabase-js@2'

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
}

// 活动数据接口
interface EventData {
  title: string
  event_time: string
  location: string
  description: string
  registration_method: string
  image_url?: string
  tags: string[]
}

// 关键词匹配规则
const AI_KEYWORDS = ['AI', '人工智能', '机器学习', '深度学习', '大模型', 'GPT', 'ChatGPT', '生成式AI', 'AIGC']
const WEB3_KEYWORDS = ['Web3', '区块链', 'blockchain', 'NFT', '元宇宙', 'DeFi', '智能合约', '加密货币', '数字货币']
const EVENT_TYPE_KEYWORDS = {
  '技术峰会': ['峰会', 'summit', '大会', 'conference'],
  '创业交流': ['创业', '投资', '路演', 'demo day'],
  '开发工作坊': ['工作坊', 'workshop', '实战', '训练营'],
  '研讨会': ['研讨会', 'seminar', '论坛', 'forum'],
  '黑客松': ['黑客松', 'hackathon', '编程马拉松']
}

// 自动分类标签
function autoTagEvent(title: string, description: string): string[] {
  const tags: string[] = []
  const text = (title + ' ' + description).toLowerCase()

  // AI相关标签
  if (AI_KEYWORDS.some((keyword) => text.includes(keyword.toLowerCase()))) {
    if (text.includes('生成式') || text.includes('aigc') || text.includes('gpt')) {
      tags.push('生成式AI')
    } else {
      tags.push('AI技术')
    }
  }

  // Web3相关标签
  if (WEB3_KEYWORDS.some((keyword) => text.includes(keyword.toLowerCase()))) {
    if (text.includes('区块链') || text.includes('blockchain')) {
      tags.push('区块链')
    }
    if (text.includes('web3')) {
      tags.push('Web3')
    }
    if (text.includes('nft')) {
      tags.push('NFT')
    }
    if (text.includes('元宇宙') || text.includes('metaverse')) {
      tags.push('元宇宙')
    }
  }

  // 活动类型标签
  for (const [tag, keywords] of Object.entries(EVENT_TYPE_KEYWORDS)) {
    if (keywords.some((keyword) => text.includes(keyword.toLowerCase()))) {
      tags.push(tag)
      break // 只添加一个活动类型标签
    }
  }

  // 如果没有匹配到任何标签，添加默认标签
  if (tags.length === 0) {
    tags.push('技术峰会')
  }

  return tags
}

// 模拟抓取活动数据（实际应用中应该从真实API或网站抓取）
async function fetchEventsFromSources(): Promise<EventData[]> {
  const events: EventData[] = []

  // 这里是模拟数据，实际应用中应该调用真实的API或爬取网站
  // 由于Edge Functions的限制，这里提供一个基础框架

  // 示例：从公开API获取数据
  try {
    // 注意：这里需要替换为真实的API端点
    // const response = await fetch('https://api.example.com/events?category=ai,web3')
    // const data = await response.json()

    // 模拟数据示例
    const mockEvents = [
      {
        title: '2026全球AI技术创新峰会',
        event_time: '2026年3月20日 09:00-18:00',
        location: '北京国家会议中心',
        description:
          '汇聚全球AI领域顶尖专家学者，探讨人工智能最新技术突破、应用场景和未来趋势。涵盖大模型、生成式AI、AI安全等热门话题。',
        registration_method: '官网报名：https://ai-summit-2026.com 或扫描二维码',
        image_url: 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_1a2b3c4d.jpg',
        tags: []
      },
      {
        title: 'Web3开发者黑客松大赛',
        event_time: '2026年4月10日 10:00-18:00',
        location: '上海张江高科技园区',
        description:
          '为期两天的Web3黑客松活动，参赛者将围绕区块链、智能合约、DeFi等主题进行创新开发。优胜团队将获得丰厚奖金和投资机会。',
        registration_method: '报名链接：https://web3-hackathon.com 联系邮箱：contact@web3hack.com',
        image_url: 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_5e6f7g8h.jpg',
        tags: []
      }
    ]

    // 自动分类标签
    for (const event of mockEvents) {
      event.tags = autoTagEvent(event.title, event.description)
      events.push(event)
    }
  } catch (error) {
    console.error('抓取活动数据失败:', error)
  }

  return events
}

// 检查活动是否已存在（基于标题和时间去重）
async function isDuplicateEvent(
  supabase: any,
  title: string,
  eventTime: string
): Promise<boolean> {
  const {data, error} = await supabase
    .from('events')
    .select('id')
    .eq('title', title)
    .eq('event_time', eventTime)
    .maybeSingle()

  if (error) {
    console.error('检查重复活动失败:', error)
    return false
  }

  return data !== null
}

// 主函数
Deno.serve(async (req) => {
  // 处理CORS预检请求
  if (req.method === 'OPTIONS') {
    return new Response('ok', {headers: corsHeaders})
  }

  try {
    // 创建Supabase客户端
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    console.log('开始抓取活动数据...')

    // 抓取活动数据
    const events = await fetchEventsFromSources()
    console.log(`抓取到 ${events.length} 个活动`)

    // 插入新活动到数据库
    let insertedCount = 0
    let skippedCount = 0

    for (const event of events) {
      // 检查是否重复
      const isDuplicate = await isDuplicateEvent(supabase, event.title, event.event_time)

      if (isDuplicate) {
        console.log(`跳过重复活动: ${event.title}`)
        skippedCount++
        continue
      }

      // 插入新活动
      const {error} = await supabase.from('events').insert({
        title: event.title,
        event_time: event.event_time,
        location: event.location,
        description: event.description,
        registration_method: event.registration_method,
        image_url: event.image_url,
        tags: event.tags
      })

      if (error) {
        console.error(`插入活动失败: ${event.title}`, error)
      } else {
        console.log(`成功插入活动: ${event.title}`)
        insertedCount++
      }
    }

    // 返回结果
    return new Response(
      JSON.stringify({
        success: true,
        message: '活动抓取完成',
        total: events.length,
        inserted: insertedCount,
        skipped: skippedCount
      }),
      {
        headers: {...corsHeaders, 'Content-Type': 'application/json'},
        status: 200
      }
    )
  } catch (error) {
    console.error('Edge Function执行失败:', error)
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        headers: {...corsHeaders, 'Content-Type': 'application/json'},
        status: 500
      }
    )
  }
})
