import {Button, Input, Text, View} from '@tarojs/components'
import Taro, {useShareAppMessage, useShareTimeline} from '@tarojs/taro'
import {useState} from 'react'
import {useAuth} from '@/contexts/AuthContext'

export default function Login() {
  const {signInWithUsername, signUpWithUsername} = useAuth()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [isLogin, setIsLogin] = useState(true)
  const [agreed, setAgreed] = useState(false)
  const [loading, setLoading] = useState(false)

  // 配置分享到好友/群聊
  useShareAppMessage(() => {
    return {
      title: '海拉的AI&WEB3 - 发现最新的AI与Web3活动',
      path: '/pages/home/index',
      imageUrl:
        'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6d9fbcee-ff32-4a84-802f-f6e6ac83c2a3.jpg'
    }
  })

  // 配置分享到朋友圈
  useShareTimeline(() => {
    return {
      title: '海拉的AI&WEB3 - 探索人工智能与区块链的未来'
    }
  })

  const handleSubmit = async () => {
    if (!username.trim() || !password.trim()) {
      Taro.showToast({
        title: '请输入用户名和密码',
        icon: 'none'
      })
      return
    }

    // 验证用户名格式
    const usernameRegex = /^[a-zA-Z0-9_]+$/
    if (!usernameRegex.test(username)) {
      Taro.showToast({
        title: '用户名只能包含字母、数字和下划线',
        icon: 'none'
      })
      return
    }

    if (!agreed) {
      Taro.showToast({
        title: '请先同意用户协议和隐私政策',
        icon: 'none'
      })
      return
    }

    setLoading(true)

    try {
      const {error} = isLogin
        ? await signInWithUsername(username, password)
        : await signUpWithUsername(username, password)

      if (error) {
        Taro.showToast({
          title: error.message || (isLogin ? '登录失败' : '注册失败'),
          icon: 'none'
        })
        return
      }

      Taro.showToast({
        title: isLogin ? '登录成功' : '注册成功',
        icon: 'success'
      })

      // 获取存储的重定向路径
      const redirectPath = Taro.getStorageSync('loginRedirectPath')
      if (redirectPath) {
        Taro.removeStorageSync('loginRedirectPath')
        // 判断是否为tabBar页面
        const tabBarPages = ['pages/home/index', 'pages/publish/index', 'pages/profile/index']
        const isTabBar = tabBarPages.some((page) => redirectPath.includes(page))

        setTimeout(() => {
          if (isTabBar) {
            Taro.switchTab({url: `/${redirectPath}`})
          } else {
            Taro.navigateTo({url: `/${redirectPath}`})
          }
        }, 500)
      } else {
        setTimeout(() => {
          Taro.switchTab({url: '/pages/home/index'})
        }, 500)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <View className="min-h-screen bg-gradient-subtle flex flex-col">
      <View className="flex-1 flex flex-col justify-center px-6">
        {/* 标题区域 */}
        <View className="mb-12 text-center">
          <View className="i-mdi-brain text-6xl text-primary mx-auto mb-4" />
          <Text className="text-3xl font-bold text-foreground block mb-2">海拉的AI&WEB3</Text>
          <Text className="text-base text-muted-foreground block">{isLogin ? '欢迎回来' : '创建新账户'}</Text>
        </View>

        {/* 表单区域 */}
        <View className="bg-card rounded-xl p-6 shadow-card">
          <View className="mb-4">
            <Text className="text-sm text-foreground mb-2 block">用户名</Text>
            <View className="bg-input rounded-lg border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                placeholder="请输入用户名"
                value={username}
                onInput={(e) => setUsername(e.detail.value)}
              />
            </View>
          </View>

          <View className="mb-6">
            <Text className="text-sm text-foreground mb-2 block">密码</Text>
            <View className="bg-input rounded-lg border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                password
                placeholder="请输入密码"
                value={password}
                onInput={(e) => setPassword(e.detail.value)}
              />
            </View>
          </View>

          {/* 协议勾选 */}
          <View className="mb-6 flex items-center" onClick={() => setAgreed(!agreed)}>
            <View
              className={`w-5 h-5 rounded border flex items-center justify-center mr-2 ${
                agreed ? 'bg-primary border-primary' : 'bg-background border-border'
              }`}>
              {agreed && <View className="i-mdi-check text-base text-primary-foreground" />}
            </View>
            <Text className="text-xs text-muted-foreground">我已阅读并同意《用户协议》和《隐私政策》</Text>
          </View>

          {/* 提交按钮 */}
          <Button
            className="w-full bg-primary text-primary-foreground text-base font-medium rounded-lg py-3 break-keep"
            loading={loading}
            onClick={handleSubmit}>
            {isLogin ? '登录' : '注册'}
          </Button>

          {/* 切换登录/注册 */}
          <View className="mt-4 text-center">
            <Text className="text-sm text-muted-foreground">{isLogin ? '还没有账户？' : '已有账户？'}</Text>
            <Text
              className="text-sm text-primary ml-2"
              onClick={() => {
                setIsLogin(!isLogin)
                setUsername('')
                setPassword('')
              }}>
              {isLogin ? '立即注册' : '立即登录'}
            </Text>
          </View>
        </View>

        {/* 提示信息 */}
        <View className="mt-8 text-center">
          <Text className="text-xs text-muted-foreground block">所有用户默认为普通用户</Text>
        </View>
      </View>
    </View>
  )
}
