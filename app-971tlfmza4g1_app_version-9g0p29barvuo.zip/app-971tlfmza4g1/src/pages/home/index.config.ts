export default definePageConfig({
  navigationBarTitleText: 'AI & WEB3 活动'
})
