-- 创建用户角色枚举
CREATE TYPE user_role AS ENUM ('user', 'admin');

-- 创建用户资料表
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  email text,
  phone text,
  role user_role NOT NULL DEFAULT 'user',
  openid text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 创建活动表
CREATE TABLE events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  event_time text NOT NULL,
  location text NOT NULL,
  description text NOT NULL,
  registration_method text NOT NULL,
  image_url text,
  created_by uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_events_created_at ON events(created_at DESC);
CREATE INDEX idx_events_created_by ON events(created_by);

-- 创建辅助函数检查管理员权限
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- 创建用户同步触发器函数
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  extracted_username text;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- 从email中提取用户名（去掉@miaoda.com后缀）
  extracted_username := CASE 
    WHEN NEW.email LIKE '%@miaoda.com' THEN 
      SUBSTRING(NEW.email FROM '^(.+)@miaoda\.com$')
    WHEN NEW.email LIKE '%@wechat.login' THEN
      NULL
    ELSE 
      NEW.email
  END;
  
  -- 插入用户资料
  INSERT INTO public.profiles (id, username, email, phone, role, openid)
  VALUES (
    NEW.id,
    extracted_username,
    CASE WHEN NEW.email LIKE '%@miaoda.com' OR NEW.email LIKE '%@wechat.login' THEN NULL ELSE NEW.email END,
    NEW.phone,
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END,
    COALESCE((NEW.raw_user_meta_data->>'openid')::text, NULL)
  );
  RETURN NEW;
END;
$$;

-- 创建触发器
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- Profiles表的RLS策略
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "管理员可以完全访问profiles" ON profiles
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以查看自己的资料" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "用户可以更新自己的资料" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- 创建公开资料视图
CREATE VIEW public_profiles AS
  SELECT id, username, role FROM profiles;

-- Events表的RLS策略
ALTER TABLE events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "所有人可以查看活动" ON events
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "管理员可以插入活动" ON events
  FOR INSERT TO authenticated 
  WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "管理员可以更新活动" ON events
  FOR UPDATE TO authenticated 
  USING (is_admin(auth.uid()));

CREATE POLICY "管理员可以删除活动" ON events
  FOR DELETE TO authenticated 
  USING (is_admin(auth.uid()));