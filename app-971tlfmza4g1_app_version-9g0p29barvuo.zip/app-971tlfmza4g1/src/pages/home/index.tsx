import {Image, ScrollView, Text, View} from '@tarojs/components'
import {useDidShow, useShareAppMessage, useShareTimeline} from '@tarojs/taro'
import {useCallback, useEffect, useMemo, useState} from 'react'
import {EventCard} from '@/components/EventCard'
import {getEvents} from '@/db/api'
import type {Event} from '@/db/types'

// 预定义的标签列表
const ALL_TAGS = [
  'AI技术',
  '区块链',
  'Web3',
  '生成式AI',
  'NFT',
  '元宇宙',
  '技术峰会',
  '创业交流',
  '开发工作坊',
  '研讨会',
  '黑客松'
]

// 时间筛选选项
type TimeFilter = 'all' | 'upcoming' | 'ongoing' | 'past'

// 判断活动状态
function getEventStatus(eventTime: string): 'upcoming' | 'ongoing' | 'past' {
  try {
    // 解析活动时间字符串，例如："2026年3月15日 09:00-18:00"
    const dateMatch = eventTime.match(/(\d{4})年(\d{1,2})月(\d{1,2})日/)
    if (!dateMatch) return 'upcoming'

    const year = parseInt(dateMatch[1], 10)
    const month = parseInt(dateMatch[2], 10) - 1 // 月份从0开始
    const day = parseInt(dateMatch[3], 10)

    const eventDate = new Date(year, month, day)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    eventDate.setHours(0, 0, 0, 0)

    const diffTime = eventDate.getTime() - today.getTime()
    const diffDays = diffTime / (1000 * 60 * 60 * 24)

    if (diffDays > 0) return 'upcoming' // 未来
    if (diffDays === 0) return 'ongoing' // 今天
    return 'past' // 过去
  } catch {
    return 'upcoming'
  }
}

function Home() {
  const [events, setEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('all')

  // 配置分享到好友/群聊
  useShareAppMessage((options) => {
    // 如果是从活动卡片分享按钮触发，从target获取事件ID
    if (options.from === 'button' && options.target) {
      const target = options.target as any
      const eventId = target.dataset?.eventId

      if (eventId) {
        const event = events.find((e) => e.id === eventId)
        if (event) {
          return {
            title: event.title,
            path: `/pages/detail/index?id=${event.id}`,
            imageUrl: event.image_url || undefined
          }
        }
      }
    }

    // 默认分享小程序主页
    return {
      title: '海拉的AI&WEB3 - 发现最新的AI与Web3活动',
      path: '/pages/home/index',
      imageUrl:
        'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6d9fbcee-ff32-4a84-802f-f6e6ac83c2a3.jpg'
    }
  })

  // 配置分享到朋友圈
  useShareTimeline(() => {
    return {
      title: '海拉的AI&WEB3 - 探索人工智能与区块链的未来'
    }
  })

  // 处理分享按钮点击（已废弃，改用data-属性）
  const handleShare = useCallback((eventId: string) => {
    // 此函数保留用于兼容，实际分享通过data-event-id传递
    console.log('分享活动:', eventId)
  }, [])

  const loadEvents = useCallback(async () => {
    setLoading(true)
    try {
      const data = await getEvents(selectedTags.length > 0 ? selectedTags : undefined)
      setEvents(data)
    } finally {
      setLoading(false)
    }
  }, [selectedTags])

  useDidShow(() => {
    loadEvents()
  })

  useEffect(() => {
    loadEvents()
  }, [loadEvents])

  // 切换标签选择
  const toggleTag = (tag: string) => {
    setSelectedTags((prev) => {
      if (prev.includes(tag)) {
        return prev.filter((t) => t !== tag)
      } else {
        return [...prev, tag]
      }
    })
  }

  // 清除所有标签
  const clearTags = () => {
    setSelectedTags([])
  }

  // 根据时间筛选过滤活动
  const filteredEvents = useMemo(() => {
    if (timeFilter === 'all') return events

    return events.filter((event) => {
      const status = getEventStatus(event.event_time)
      return status === timeFilter
    })
  }, [events, timeFilter])

  // 计算每个标签的活动数量（基于时间筛选后的活动）
  const tagCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    filteredEvents.forEach((event) => {
      event.tags?.forEach((tag) => {
        counts[tag] = (counts[tag] || 0) + 1
      })
    })
    return counts
  }, [filteredEvents])

  return (
    <View className="min-h-screen bg-gradient-subtle">
      {/* AI&Web3主题封面 */}
      <View className="relative w-full bg-gradient-primary overflow-hidden">
        {/* 背景图片 - AI和Web3融合科技背景 */}
        <Image
          src="https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6d9fbcee-ff32-4a84-802f-f6e6ac83c2a3.jpg"
          mode="aspectFill"
          className="w-full h-48 opacity-40"
        />

        {/* 封面内容 */}
        <View className="absolute inset-0 flex flex-col items-center justify-center px-6">
          <View className="flex items-center justify-center mb-3">
            <View className="i-mdi-brain text-4xl text-primary-foreground mr-2" />
            <View className="i-mdi-link-variant text-3xl text-primary-foreground" />
          </View>
          <Text className="text-3xl font-bold text-primary-foreground block mb-2 text-center">海拉的AI&WEB3</Text>
          <Text className="text-sm text-primary-foreground opacity-90 block text-center mb-1">
            探索人工智能与区块链的未来
          </Text>
          <Text className="text-xs text-primary-foreground opacity-75 block text-center">发现最新的AI与Web3活动</Text>
        </View>
      </View>

      {/* 时间筛选区域 */}
      <View className="bg-card px-4 py-3 border-b border-border">
        <Text className="text-sm font-medium text-foreground mb-2 block">时间筛选</Text>
        <View className="flex gap-2">
          <View
            className={`flex-1 px-3 py-2 rounded-lg text-center ${
              timeFilter === 'all' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
            }`}
            onClick={() => setTimeFilter('all')}>
            <Text className="text-sm">全部</Text>
          </View>
          <View
            className={`flex-1 px-3 py-2 rounded-lg text-center ${
              timeFilter === 'upcoming' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
            }`}
            onClick={() => setTimeFilter('upcoming')}>
            <Text className="text-sm">即将开始</Text>
          </View>
          <View
            className={`flex-1 px-3 py-2 rounded-lg text-center ${
              timeFilter === 'ongoing' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
            }`}
            onClick={() => setTimeFilter('ongoing')}>
            <Text className="text-sm">进行中</Text>
          </View>
          <View
            className={`flex-1 px-3 py-2 rounded-lg text-center ${
              timeFilter === 'past' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
            }`}
            onClick={() => setTimeFilter('past')}>
            <Text className="text-sm">已结束</Text>
          </View>
        </View>
      </View>

      {/* 标签筛选区域 */}
      <View className="bg-card px-4 py-3 border-b border-border">
        <View className="flex items-center justify-between mb-2">
          <Text className="text-sm font-medium text-foreground">活动分类</Text>
          {selectedTags.length > 0 && (
            <View className="flex items-center" onClick={clearTags}>
              <View className="i-mdi-close-circle text-base text-muted-foreground mr-1" />
              <Text className="text-xs text-muted-foreground">清除</Text>
            </View>
          )}
        </View>
        <View className="flex flex-wrap gap-2">
          {ALL_TAGS.map((tag) => {
            const isSelected = selectedTags.includes(tag)
            const count = tagCounts[tag] || 0
            return (
              <View
                key={tag}
                className={`px-3 py-1 rounded-full text-xs ${
                  isSelected ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                }`}
                onClick={() => toggleTag(tag)}>
                <Text className="text-xs">
                  {tag} {count > 0 ? `(${count})` : ''}
                </Text>
              </View>
            )
          })}
        </View>
      </View>

      {/* 活动列表 */}
      <ScrollView scrollY className="flex-1 px-6 pt-4" style={{height: 'calc(100vh - 400px)'}}>
        {loading ? (
          <View className="flex flex-col items-center justify-center py-20">
            <View className="i-mdi-loading text-4xl text-primary animate-spin mb-4" />
            <Text className="text-sm text-muted-foreground">加载中...</Text>
          </View>
        ) : filteredEvents.length === 0 ? (
          <View className="flex flex-col items-center justify-center py-20">
            <View className="i-mdi-calendar-blank text-6xl text-muted mb-4" />
            <Text className="text-base text-muted-foreground">
              {selectedTags.length > 0 || timeFilter !== 'all' ? '没有符合条件的活动' : '暂无活动'}
            </Text>
          </View>
        ) : (
          <View className="pb-4">
            {filteredEvents.map((event) => (
              <EventCard key={event.id} event={event} onShare={handleShare} />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  )
}

export default Home
