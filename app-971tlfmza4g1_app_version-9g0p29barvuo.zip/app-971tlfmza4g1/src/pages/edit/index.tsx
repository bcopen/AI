import {Button, Input, Picker, ScrollView, Text, Textarea, View} from '@tarojs/components'
import Taro, {useRouter, useShareAppMessage, useShareTimeline} from '@tarojs/taro'
import {useCallback, useEffect, useState} from 'react'
import {withRouteGuard} from '@/components/RouteGuard'
import {useAuth} from '@/contexts/AuthContext'
import {checkIsAdmin, getEventById, updateEvent} from '@/db/api'

// 预定义的标签列表
const ALL_TAGS = [
  'AI技术',
  '区块链',
  'Web3',
  '生成式AI',
  'NFT',
  '元宇宙',
  '技术峰会',
  '创业交流',
  '开发工作坊',
  '研讨会',
  '黑客松'
]

function Edit() {
  const router = useRouter()
  const {id} = router.params
  const {user} = useAuth()
  const [isAdmin, setIsAdmin] = useState(false)
  const [loading, setLoading] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)
  const [loadingEvent, setLoadingEvent] = useState(true)

  // 配置分享到好友/群聊
  useShareAppMessage(() => {
    return {
      title: '海拉的AI&WEB3 - 发现最新的AI与Web3活动',
      path: '/pages/home/index',
      imageUrl:
        'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6d9fbcee-ff32-4a84-802f-f6e6ac83c2a3.jpg'
    }
  })

  // 配置分享到朋友圈
  useShareTimeline(() => {
    return {
      title: '海拉的AI&WEB3 - 探索人工智能与区块链的未来'
    }
  })

  // 时间选择器相关状态
  const [selectedDate, setSelectedDate] = useState('')
  const [selectedStartTime, setSelectedStartTime] = useState('')
  const [selectedEndTime, setSelectedEndTime] = useState('')

  // 标签选择状态
  const [selectedTags, setSelectedTags] = useState<string[]>([])

  const [formData, setFormData] = useState({
    title: '',
    event_time: '',
    location: '',
    description: '',
    registration_method: ''
  })

  const checkAdmin = useCallback(async () => {
    setCheckingAdmin(true)
    try {
      const adminStatus = await checkIsAdmin()
      setIsAdmin(adminStatus)
    } finally {
      setCheckingAdmin(false)
    }
  }, [])

  const loadEvent = useCallback(async (eventId: string) => {
    setLoadingEvent(true)
    try {
      const event = await getEventById(eventId)
      if (event) {
        setFormData({
          title: event.title,
          event_time: event.event_time,
          location: event.location,
          description: event.description,
          registration_method: event.registration_method
        })
        setSelectedTags(event.tags || [])
      }
    } finally {
      setLoadingEvent(false)
    }
  }, [])

  useEffect(() => {
    if (user) {
      checkAdmin()
    }
    if (id) {
      loadEvent(id)
    }
  }, [user, id, checkAdmin, loadEvent])

  // 处理日期选择
  const handleDateChange = (e: any) => {
    const date = e.detail.value
    setSelectedDate(date)
    updateEventTime(date, selectedStartTime, selectedEndTime)
  }

  // 处理开始时间选择
  const handleStartTimeChange = (e: any) => {
    const time = e.detail.value
    setSelectedStartTime(time)
    updateEventTime(selectedDate, time, selectedEndTime)
  }

  // 处理结束时间选择
  const handleEndTimeChange = (e: any) => {
    const time = e.detail.value
    setSelectedEndTime(time)
    updateEventTime(selectedDate, selectedStartTime, time)
  }

  // 更新活动时间字符串
  const updateEventTime = (date: string, startTime: string, endTime: string) => {
    if (!date) return

    // 格式化日期：2026-02-15 -> 2026年2月15日
    const [year, month, day] = date.split('-')
    let timeStr = `${year}年${parseInt(month, 10)}月${parseInt(day, 10)}日`

    // 添加时间范围
    if (startTime && endTime) {
      timeStr += ` ${startTime}-${endTime}`
    } else if (startTime) {
      timeStr += ` ${startTime}`
    }

    setFormData({...formData, event_time: timeStr})
  }

  // 切换标签选择
  const toggleTag = (tag: string) => {
    setSelectedTags((prev) => {
      if (prev.includes(tag)) {
        return prev.filter((t) => t !== tag)
      } else {
        return [...prev, tag]
      }
    })
  }

  const handleSubmit = async () => {
    if (!id) return

    // 验证表单
    if (
      !formData.title.trim() ||
      !formData.event_time.trim() ||
      !formData.location.trim() ||
      !formData.description.trim() ||
      !formData.registration_method.trim()
    ) {
      Taro.showToast({
        title: '请填写完整信息',
        icon: 'none'
      })
      return
    }

    if (selectedTags.length === 0) {
      Taro.showToast({
        title: '请至少选择一个标签',
        icon: 'none'
      })
      return
    }

    setLoading(true)

    try {
      const result = await updateEvent(id, {
        ...formData,
        tags: selectedTags
      })

      if (result) {
        Taro.showToast({
          title: '更新成功',
          icon: 'success'
        })

        // 返回详情页
        setTimeout(() => {
          Taro.navigateBack()
        }, 1000)
      } else {
        Taro.showToast({
          title: '更新失败',
          icon: 'none'
        })
      }
    } finally {
      setLoading(false)
    }
  }

  if (checkingAdmin || loadingEvent) {
    return (
      <View className="min-h-screen bg-gradient-subtle flex flex-col items-center justify-center">
        <View className="i-mdi-loading text-4xl text-primary animate-spin mb-4" />
        <Text className="text-sm text-muted-foreground">加载中...</Text>
      </View>
    )
  }

  if (!isAdmin) {
    return (
      <View className="min-h-screen bg-gradient-subtle flex flex-col items-center justify-center px-6">
        <View className="i-mdi-lock text-6xl text-muted mb-4" />
        <Text className="text-xl font-bold text-foreground mb-2">权限不足</Text>
        <Text className="text-sm text-muted-foreground text-center mb-6">只有管理员才能编辑活动</Text>
        <Button
          className="bg-primary text-primary-foreground text-sm px-8 py-2 rounded-lg break-keep"
          onClick={() => Taro.navigateBack()}>
          返回
        </Button>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gradient-subtle">
      {/* 头部 */}
      <View className="bg-gradient-primary px-6 pt-12 pb-8">
        <Text className="text-2xl font-bold text-primary-foreground block mb-2">编辑活动</Text>
        <Text className="text-sm text-primary-foreground opacity-90 block">修改活动信息</Text>
      </View>

      {/* 表单 */}
      <ScrollView scrollY className="flex-1 px-6 pt-6" style={{height: 'calc(100vh - 180px)'}}>
        <View className="pb-6">
          {/* 活动名称 */}
          <View className="mb-4">
            <Text className="text-sm text-foreground mb-2 block">活动名称</Text>
            <View className="bg-card rounded-lg border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                placeholder="请输入活动名称"
                value={formData.title}
                onInput={(e) => setFormData({...formData, title: e.detail.value})}
              />
            </View>
          </View>

          {/* 活动时间 */}
          <View className="mb-4">
            <Text className="text-sm text-foreground mb-2 block">活动时间</Text>

            {/* 时间选择器组 */}
            <View className="flex gap-2 mb-2">
              {/* 日期选择器 */}
              <Picker mode="date" onChange={handleDateChange} value={selectedDate}>
                <View className="flex-1 bg-accent rounded-lg border border-border px-3 py-2 flex items-center justify-center">
                  <View className="i-mdi-calendar text-lg text-accent-foreground mr-2" />
                  <Text className="text-sm text-accent-foreground">{selectedDate || '选择日期'}</Text>
                </View>
              </Picker>

              {/* 开始时间选择器 */}
              <Picker mode="time" onChange={handleStartTimeChange} value={selectedStartTime}>
                <View className="flex-1 bg-accent rounded-lg border border-border px-3 py-2 flex items-center justify-center">
                  <View className="i-mdi-clock-start text-lg text-accent-foreground mr-2" />
                  <Text className="text-sm text-accent-foreground">{selectedStartTime || '开始'}</Text>
                </View>
              </Picker>

              {/* 结束时间选择器 */}
              <Picker mode="time" onChange={handleEndTimeChange} value={selectedEndTime}>
                <View className="flex-1 bg-accent rounded-lg border border-border px-3 py-2 flex items-center justify-center">
                  <View className="i-mdi-clock-end text-lg text-accent-foreground mr-2" />
                  <Text className="text-sm text-accent-foreground">{selectedEndTime || '结束'}</Text>
                </View>
              </Picker>
            </View>

            {/* 手动输入框 */}
            <View className="bg-card rounded-lg border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                placeholder="或手动输入，例如：2026年2月15日 14:00-17:00"
                value={formData.event_time}
                onInput={(e) => setFormData({...formData, event_time: e.detail.value})}
              />
            </View>
          </View>

          {/* 活动地点 */}
          <View className="mb-4">
            <Text className="text-sm text-foreground mb-2 block">活动地点</Text>
            <View className="bg-card rounded-lg border border-border px-4 py-3">
              <Input
                className="w-full text-foreground"
                placeholder="请输入活动地点"
                value={formData.location}
                onInput={(e) => setFormData({...formData, location: e.detail.value})}
              />
            </View>
          </View>

          {/* 活动介绍 */}
          <View className="mb-4">
            <Text className="text-sm text-foreground mb-2 block">活动介绍</Text>
            <View className="bg-card rounded-lg border border-border px-4 py-3">
              <Textarea
                className="w-full text-foreground"
                placeholder="请输入活动介绍"
                value={formData.description}
                onInput={(e) => setFormData({...formData, description: e.detail.value})}
                style={{minHeight: '120px'}}
              />
            </View>
          </View>

          {/* 报名方式 */}
          <View className="mb-4">
            <Text className="text-sm text-foreground mb-2 block">报名方式</Text>
            <View className="bg-card rounded-lg border border-border px-4 py-3">
              <Textarea
                className="w-full text-foreground"
                placeholder="请输入报名方式"
                value={formData.registration_method}
                onInput={(e) => setFormData({...formData, registration_method: e.detail.value})}
                style={{minHeight: '80px'}}
              />
            </View>
          </View>

          {/* 活动标签 */}
          <View className="mb-6">
            <Text className="text-sm text-foreground mb-2 block">
              活动标签 <Text className="text-xs text-muted-foreground">(至少选择一个)</Text>
            </Text>
            <View className="bg-card rounded-lg border border-border p-4">
              <View className="flex flex-wrap gap-2">
                {ALL_TAGS.map((tag) => {
                  const isSelected = selectedTags.includes(tag)
                  return (
                    <View
                      key={tag}
                      className={`px-3 py-2 rounded-full text-sm ${
                        isSelected ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                      }`}
                      onClick={() => toggleTag(tag)}>
                      <Text className="text-sm">{tag}</Text>
                    </View>
                  )
                })}
              </View>
              {selectedTags.length > 0 && (
                <View className="mt-3 pt-3 border-t border-border">
                  <Text className="text-xs text-muted-foreground">
                    已选择 {selectedTags.length} 个标签：{selectedTags.join('、')}
                  </Text>
                </View>
              )}
            </View>
          </View>

          {/* 提交按钮 */}
          <Button
            className="w-full bg-primary text-primary-foreground text-base font-medium rounded-lg py-3 break-keep mb-4"
            loading={loading}
            onClick={handleSubmit}>
            保存修改
          </Button>

          {/* 取消按钮 */}
          <Button
            className="w-full bg-secondary text-secondary-foreground text-base font-medium rounded-lg py-3 break-keep mb-6"
            onClick={() => Taro.navigateBack()}>
            取消
          </Button>
        </View>
      </ScrollView>
    </View>
  )
}

export default withRouteGuard(Edit)
