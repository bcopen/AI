import {Button, ScrollView, Text, View} from '@tarojs/components'
import Taro, {useDidShow, useShareAppMessage, useShareTimeline} from '@tarojs/taro'
import {useCallback, useState} from 'react'
import {supabase} from '@/client/supabase'
import {withRouteGuard} from '@/components/RouteGuard'
import {useAuth} from '@/contexts/AuthContext'
import {checkIsAdmin} from '@/db/api'

interface FetchLog {
  timestamp: string
  total: number
  inserted: number
  skipped: number
  success: boolean
  message: string
}

function AutoFetch() {
  const {user} = useAuth()
  const [isAdmin, setIsAdmin] = useState(false)
  const [loading, setLoading] = useState(false)
  const [fetching, setFetching] = useState(false)
  const [logs, setLogs] = useState<FetchLog[]>([])

  // 配置分享
  useShareAppMessage(() => ({
    title: '海拉的AI&WEB3 - 发现最新的AI与Web3活动',
    path: '/pages/home/index',
    imageUrl:
      'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6d9fbcee-ff32-4a84-802f-f6e6ac83c2a3.jpg'
  }))

  useShareTimeline(() => ({
    title: '海拉的AI&WEB3 - 探索人工智能与区块链的未来'
  }))

  const checkAdmin = useCallback(async () => {
    setLoading(true)
    try {
      const adminStatus = await checkIsAdmin()
      setIsAdmin(adminStatus)

      if (!adminStatus) {
        Taro.showToast({
          title: '仅管理员可访问',
          icon: 'none'
        })
        setTimeout(() => {
          Taro.navigateBack()
        }, 1500)
      }
    } finally {
      setLoading(false)
    }
  }, [])

  useDidShow(() => {
    checkAdmin()
  })

  // 手动触发抓取
  const handleFetch = async () => {
    setFetching(true)

    try {
      Taro.showLoading({
        title: '正在抓取活动...',
        mask: true
      })

      // 调用Edge Function
      const {data, error} = await supabase.functions.invoke('fetch-events', {
        method: 'POST'
      })

      Taro.hideLoading()

      if (error) {
        throw error
      }

      // 添加日志
      const newLog: FetchLog = {
        timestamp: new Date().toLocaleString('zh-CN'),
        total: data.total || 0,
        inserted: data.inserted || 0,
        skipped: data.skipped || 0,
        success: data.success || false,
        message: data.message || '抓取完成'
      }

      setLogs((prev) => [newLog, ...prev])

      Taro.showToast({
        title: `成功添加${data.inserted}个活动`,
        icon: 'success'
      })
    } catch (error: any) {
      Taro.hideLoading()

      const errorLog: FetchLog = {
        timestamp: new Date().toLocaleString('zh-CN'),
        total: 0,
        inserted: 0,
        skipped: 0,
        success: false,
        message: error.message || '抓取失败'
      }

      setLogs((prev) => [errorLog, ...prev])

      Taro.showToast({
        title: '抓取失败',
        icon: 'none'
      })
    } finally {
      setFetching(false)
    }
  }

  const handleBack = () => {
    Taro.navigateBack()
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-gradient-subtle flex items-center justify-center">
        <View className="i-mdi-loading text-4xl text-primary animate-spin" />
      </View>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <View className="min-h-screen bg-gradient-subtle">
      {/* 头部 */}
      <View className="bg-gradient-primary px-6 py-4 flex items-center">
        <Button
          className="bg-transparent text-primary-foreground text-base font-medium p-0 border-0 flex items-center"
          onClick={handleBack}>
          <View className="flex items-center">
            <View className="i-mdi-arrow-left text-xl text-primary-foreground mr-2" />
            <Text className="text-base text-primary-foreground">返回</Text>
          </View>
        </Button>
        <Text className="flex-1 text-center text-lg font-bold text-primary-foreground">自动抓取活动</Text>
        <View style={{width: '60px'}} />
      </View>

      <ScrollView scrollY className="flex-1" style={{height: 'calc(100vh - 60px)'}}>
        <View className="px-6 py-6">
          {/* 功能说明 */}
          <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
            <View className="flex items-center mb-3">
              <View className="i-mdi-information text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">功能说明</Text>
            </View>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              系统会自动从全网抓取AI和Web3相关活动，并智能分类打标签。
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              • 自动识别活动类型（技术峰会、工作坊、黑客松等）
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">• 自动去重，避免重复添加相同活动</Text>
            <Text className="text-sm text-muted-foreground leading-relaxed">• 支持手动触发和定时自动抓取</Text>
          </View>

          {/* 操作按钮 */}
          <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
            <Text className="text-base font-bold text-foreground mb-3">手动抓取</Text>
            <Button
              className="w-full bg-primary text-primary-foreground text-base font-medium rounded-lg py-3 break-keep"
              loading={fetching}
              onClick={handleFetch}>
              <View className="flex items-center justify-center">
                <View className="i-mdi-cloud-download text-xl mr-2" />
                <Text className="text-base">立即抓取活动</Text>
              </View>
            </Button>
          </View>

          {/* 定时任务说明 */}
          <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
            <View className="flex items-center mb-3">
              <View className="i-mdi-clock-outline text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">定时任务</Text>
            </View>
            <Text className="text-sm text-muted-foreground leading-relaxed mb-2">
              系统已配置每天凌晨2点自动抓取活动数据。
            </Text>
            <Text className="text-sm text-muted-foreground leading-relaxed">如需修改定时任务，请联系技术管理员。</Text>
          </View>

          {/* 抓取日志 */}
          <View className="bg-card rounded-xl p-4 shadow-card">
            <View className="flex items-center mb-3">
              <View className="i-mdi-history text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">抓取日志</Text>
            </View>

            {logs.length === 0 ? (
              <View className="flex flex-col items-center justify-center py-8">
                <View className="i-mdi-file-document-outline text-4xl text-muted mb-2" />
                <Text className="text-sm text-muted-foreground">暂无抓取记录</Text>
              </View>
            ) : (
              <View>
                {logs.map((log, index) => (
                  <View
                    key={index}
                    className={`p-3 rounded-lg mb-2 ${log.success ? 'bg-primary bg-opacity-10' : 'bg-destructive bg-opacity-10'}`}>
                    <View className="flex items-center justify-between mb-2">
                      <Text className="text-xs text-muted-foreground">{log.timestamp}</Text>
                      <View className={`px-2 py-0.5 rounded ${log.success ? 'bg-primary' : 'bg-destructive'}`}>
                        <Text
                          className={`text-xs ${log.success ? 'text-primary-foreground' : 'text-destructive-foreground'}`}>
                          {log.success ? '成功' : '失败'}
                        </Text>
                      </View>
                    </View>
                    <Text className="text-sm text-foreground mb-1">{log.message}</Text>
                    {log.success && (
                      <Text className="text-xs text-muted-foreground">
                        共抓取 {log.total} 个，新增 {log.inserted} 个，跳过 {log.skipped} 个
                      </Text>
                    )}
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </View>
  )
}

export default withRouteGuard(AutoFetch)
