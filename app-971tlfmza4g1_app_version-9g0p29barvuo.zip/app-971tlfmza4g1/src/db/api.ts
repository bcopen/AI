// 数据库操作API
import {supabase} from '@/client/supabase'
import type {Event, Profile} from './types'

// ========== 用户相关 ==========

/**
 * 获取当前用户资料
 */
export async function getCurrentProfile(): Promise<Profile | null> {
  const {
    data: {user}
  } = await supabase.auth.getUser()
  if (!user) return null

  const {data} = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle()

  return data
}

/**
 * 检查用户是否为管理员
 */
export async function checkIsAdmin(): Promise<boolean> {
  const profile = await getCurrentProfile()
  return profile?.role === 'admin'
}

// ========== 活动相关 ==========

/**
 * 获取所有活动列表
 * @param tags 可选的标签筛选
 */
export async function getEvents(tags?: string[]): Promise<Event[]> {
  let query = supabase.from('events').select('*').order('created_at', {ascending: false})

  // 如果有标签筛选，使用overlaps操作符
  if (tags && tags.length > 0) {
    query = query.overlaps('tags', tags)
  }

  const {data} = await query

  return Array.isArray(data) ? data : []
}

/**
 * 根据ID获取活动详情
 */
export async function getEventById(id: string): Promise<Event | null> {
  const {data} = await supabase.from('events').select('*').eq('id', id).maybeSingle()

  return data
}

/**
 * 创建新活动
 */
export async function createEvent(event: {
  title: string
  event_time: string
  location: string
  description: string
  registration_method: string
  image_url?: string
  tags?: string[]
}): Promise<Event | null> {
  const {
    data: {user}
  } = await supabase.auth.getUser()
  if (!user) return null

  const {data} = await supabase
    .from('events')
    .insert({
      ...event,
      created_by: user.id,
      image_url: event.image_url || null,
      tags: event.tags || []
    })
    .select()
    .maybeSingle()

  return data
}

/**
 * 更新活动
 */
export async function updateEvent(
  id: string,
  updates: Partial<Omit<Event, 'id' | 'created_by' | 'created_at'>>
): Promise<Event | null> {
  const {data} = await supabase.from('events').update(updates).eq('id', id).select().maybeSingle()

  return data
}

/**
 * 删除活动
 */
export async function deleteEvent(id: string): Promise<boolean> {
  const {error} = await supabase.from('events').delete().eq('id', id)

  return !error
}
