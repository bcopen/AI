export default definePageConfig({
  navigationBarTitleText: '海拉的AI&WEB3'
})
