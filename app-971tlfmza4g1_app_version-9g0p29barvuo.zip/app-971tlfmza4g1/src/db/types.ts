// 数据库类型定义

export type UserRole = 'user' | 'admin'

export interface Profile {
  id: string
  username: string | null
  email: string | null
  phone: string | null
  role: UserRole
  openid: string | null
  created_at: string
}

export interface Event {
  id: string
  title: string
  event_time: string
  location: string
  description: string
  registration_method: string
  image_url: string | null
  tags: string[]
  created_by: string
  created_at: string
}

export interface EventWithCreator extends Event {
  creator?: {
    id: string
    username: string | null
    role: UserRole
  }
}
