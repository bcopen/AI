export default definePageConfig({
  navigationBarTitleText: '自动抓取活动'
})
