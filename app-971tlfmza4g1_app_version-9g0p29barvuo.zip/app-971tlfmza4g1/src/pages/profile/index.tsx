import {Button, Text, View} from '@tarojs/components'
import Taro, {useShareAppMessage, useShareTimeline} from '@tarojs/taro'
import {useCallback, useEffect, useState} from 'react'
import {withRouteGuard} from '@/components/RouteGuard'
import {useAuth} from '@/contexts/AuthContext'
import {getCurrentProfile} from '@/db/api'
import type {Profile} from '@/db/types'

function ProfilePage() {
  const {user, signOut} = useAuth()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)

  // 配置分享到好友/群聊
  useShareAppMessage(() => {
    return {
      title: '海拉的AI&WEB3 - 发现最新的AI与Web3活动',
      path: '/pages/home/index',
      imageUrl:
        'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6d9fbcee-ff32-4a84-802f-f6e6ac83c2a3.jpg'
    }
  })

  // 配置分享到朋友圈
  useShareTimeline(() => {
    return {
      title: '海拉的AI&WEB3 - 探索人工智能与区块链的未来'
    }
  })

  const loadProfile = useCallback(async () => {
    setLoading(true)
    try {
      const data = await getCurrentProfile()
      setProfile(data)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (user) {
      loadProfile()
    }
  }, [user, loadProfile])

  const handleLogout = async () => {
    Taro.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: async (res) => {
        if (res.confirm) {
          await signOut()
          Taro.showToast({
            title: '已退出登录',
            icon: 'success'
          })
          setTimeout(() => {
            Taro.reLaunch({url: '/pages/login/index'})
          }, 500)
        }
      }
    })
  }

  if (loading) {
    return (
      <View className="min-h-screen bg-gradient-subtle flex items-center justify-center">
        <View className="i-mdi-loading text-4xl text-primary animate-spin mb-4" />
        <Text className="text-sm text-muted-foreground">加载中...</Text>
      </View>
    )
  }

  return (
    <View className="min-h-screen bg-gradient-subtle">
      {/* 头部 */}
      <View className="bg-gradient-primary px-6 pt-12 pb-8">
        <View className="flex items-center">
          <View className="w-16 h-16 bg-primary-foreground rounded-full flex items-center justify-center mr-4">
            <View className="i-mdi-account text-3xl text-primary" />
          </View>
          <View className="flex-1">
            <Text className="text-xl font-bold text-primary-foreground block mb-1">{profile?.username || '用户'}</Text>
            <View className="flex items-center">
              <View
                className={`px-2 py-1 rounded text-xs ${
                  profile?.role === 'admin'
                    ? 'bg-primary-foreground text-primary'
                    : 'bg-primary-foreground bg-opacity-20 text-primary-foreground'
                }`}>
                <Text className="text-xs">{profile?.role === 'admin' ? '管理员' : '普通用户'}</Text>
              </View>
            </View>
          </View>
        </View>
      </View>

      {/* 内容区域 */}
      <View className="px-6 pt-6">
        {/* 用户信息卡片 */}
        <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
          <View className="flex items-center mb-3 pb-3 border-b border-border">
            <View className="i-mdi-account-circle text-xl text-primary mr-3" />
            <View className="flex-1">
              <Text className="text-xs text-muted-foreground block mb-1">用户名</Text>
              <Text className="text-base text-foreground block">{profile?.username || '未设置'}</Text>
            </View>
          </View>

          <View className="flex items-center">
            <View className="i-mdi-shield-account text-xl text-primary mr-3" />
            <View className="flex-1">
              <Text className="text-xs text-muted-foreground block mb-1">角色</Text>
              <Text className="text-base text-foreground block">
                {profile?.role === 'admin' ? '管理员' : '普通用户'}
              </Text>
            </View>
          </View>
        </View>

        {/* 管理员功能区 */}
        {profile?.role === 'admin' && (
          <View className="bg-card rounded-xl p-4 mb-4 shadow-card">
            <View className="flex items-center mb-3">
              <View className="i-mdi-shield-crown text-xl text-primary mr-2" />
              <Text className="text-base font-bold text-foreground">管理员功能</Text>
            </View>
            <Button
              className="w-full bg-primary text-primary-foreground text-base font-medium rounded-lg py-3 break-keep mb-3"
              onClick={() => Taro.navigateTo({url: '/pages/publish/index'})}>
              <View className="flex items-center justify-center">
                <View className="i-mdi-plus-circle text-lg mr-2" />
                <Text className="text-base">发布新活动</Text>
              </View>
            </Button>
            <Button
              className="w-full bg-accent text-accent-foreground text-base font-medium rounded-lg py-3 break-keep mb-3"
              onClick={() => Taro.navigateTo({url: '/pages/auto-fetch/index'})}>
              <View className="flex items-center justify-center">
                <View className="i-mdi-cloud-sync text-lg mr-2" />
                <Text className="text-base">自动抓取活动</Text>
              </View>
            </Button>
            <View className="bg-accent bg-opacity-10 rounded-lg p-3">
              <View className="flex items-start">
                <View className="i-mdi-information text-lg text-primary mr-2 mt-0.5" />
                <View className="flex-1">
                  <Text className="text-xs text-muted-foreground block leading-relaxed">
                    您可以发布、编辑和删除活动信息，也可以使用自动抓取功能从全网获取AI和Web3活动
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}

        {/* 普通用户说明 */}
        {profile?.role !== 'admin' && (
          <View className="bg-accent rounded-xl p-4 mb-6">
            <View className="flex items-start">
              <View className="i-mdi-information text-xl text-accent-foreground mr-3 mt-0.5" />
              <View className="flex-1">
                <Text className="text-sm text-accent-foreground block leading-relaxed">
                  您可以浏览所有AI和Web3活动信息，查看活动详情
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* 退出登录按钮 */}
        <Button
          className="w-full bg-destructive text-destructive-foreground text-base font-medium rounded-lg py-3 break-keep"
          onClick={handleLogout}>
          退出登录
        </Button>
      </View>
    </View>
  )
}

export default withRouteGuard(ProfilePage)
